﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeuSegundoProjeto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Pressione a tecla A para alugar um filme ou S para sair da locadora:");
            char opcao = Console.ReadKey(true).KeyChar;

            if (opcao == 'a' || opcao == 'A') //alugar um filme
            {
                Console.WriteLine("Pressione 1 para alugar top gun");
                Console.WriteLine("Pressione 2 para alugar bela e a fera");
                Console.WriteLine("Pressione 3 para alugar Espetacular Homem aranha");
                int opcaoFilme = Convert.ToInt32(Console.ReadKey(true).KeyChar.ToString());

                switch (opcaoFilme)
                {
                    case 1:
                        Console.WriteLine("Voce alugou tog gun");
                        break;
                    case 2:
                        Console.WriteLine("Voce alugou a bela e a fera");
                        break;
                    case 3:
                        Console.WriteLine("Voce alugou Espetacular Homem-aranha");
                        break;
                    default:
                        Console.WriteLine("Opção desconhecida");
                        break;
                }
            }
            else if (opcao == 's' || opcao == 'S') //Sair da locadora
            {
                Console.WriteLine("Muito obrigado, volte sempre!");
            }
            else //Opção desconhecida
            {

            }
            Console.WriteLine("Pressione qualquer tecla para sair");
            Console.ReadKey(); 

        }
    }
}
